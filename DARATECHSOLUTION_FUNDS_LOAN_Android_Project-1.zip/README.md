# DARATECHSOLUTION FUNDS LOAN — Android starter project

This is an Android Studio project source, not a compiled APK.

## Current configured terms
- Fixed requested amount: NGN 5,000
- Interest: 20% (NGN 1,000)
- Repayment period: 7 days
- Total repayment shown: NGN 6,000
- WhatsApp contact: +234 707 291 3251

## Build an APK
1. Open this folder in Android Studio (a recent version).
2. Allow Gradle sync and install Android SDK Platform 35 if prompted.
3. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
4. Android Studio will show the generated APK location.

## Important limitations and launch checklist
- This project source has not been compiled or tested on a device in this environment.
- The form opens WhatsApp with the application text. It does **not** automatically attach the video; the applicant must attach it manually in WhatsApp after the chat opens.
- The app does not store the application or video on a server.
- Before accepting real applications, obtain Nigerian legal/regulatory advice on lending authorization, pricing/disclosure, fair collection practices and NDPA-compliant privacy/security. Add a verified privacy notice, lender identity/address, complaint contact, clear due-date calculation, and final loan agreement.
- Never request a customer's PIN, password, OTP, CVV or card credentials. Consider collecting account details through a secure, access-controlled channel rather than a WhatsApp message.
